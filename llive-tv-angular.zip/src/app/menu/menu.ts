export class Menu {
  id: number;
  item_type: string;
  name: string;
  order: number;
  slug: string;
}
