/* All animations in this folder should be listed here */
export * from './fade-in.animation';
