export interface Tab {
  tabTitle: string
}
