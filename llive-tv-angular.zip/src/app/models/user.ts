export class User {
  name: string;
  email: string;
  accountToken: string;
  currProfileToken: string;
}
