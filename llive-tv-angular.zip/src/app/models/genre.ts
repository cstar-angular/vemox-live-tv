export class Genre {
  type: string;
  name: string;
  slug: string;
  image: any;
}
