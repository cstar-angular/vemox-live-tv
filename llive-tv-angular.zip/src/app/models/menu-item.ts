import {MenuOption} from './menu-option';
import {Screen} from './screen';

export class MenuItem {
  menu_option: MenuOption;
  screen: Screen;
}
