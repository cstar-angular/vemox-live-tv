var Seo = (function () {
    function Seo() {
    }
    return Seo;
}());
export { Seo };
//# sourceMappingURL=seo.js.map