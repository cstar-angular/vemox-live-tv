import {Keywords} from './keywords';

export class Seo {
  description: string;
  keywords: Keywords[];
  name: string;
}
