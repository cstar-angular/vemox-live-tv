var Cast = (function () {
    function Cast() {
    }
    return Cast;
}());
export { Cast };
//# sourceMappingURL=cast.js.map