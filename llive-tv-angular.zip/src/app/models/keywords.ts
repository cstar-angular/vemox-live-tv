export class Keywords {
  name: string;
}
