export class Images {
  backdrop: any;
  banner: any;
  poster: any;
  square: any;
  thumbnail: any;
  wide_banner: any;
}
