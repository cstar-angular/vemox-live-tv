export interface AgeRatings {
  data: [
    {
      id: string,
      name: string,
      description: string,
      level: string,
      country_code: string,
      image: {
        url: string
      }
    }
  ]
}
