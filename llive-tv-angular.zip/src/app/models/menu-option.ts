export class MenuOption {
  name: string;
  option_type: string;
  slug: string;
}
