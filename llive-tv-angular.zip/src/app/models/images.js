var Images = (function () {
    function Images() {
    }
    return Images;
}());
export { Images };
//# sourceMappingURL=images.js.map