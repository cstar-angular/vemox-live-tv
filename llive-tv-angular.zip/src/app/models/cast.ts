export class Cast {
  id: number;
  name: string;
}
