var Playlist = (function () {
    function Playlist() {
    }
    return Playlist;
}());
export { Playlist };
//# sourceMappingURL=playlist.js.map