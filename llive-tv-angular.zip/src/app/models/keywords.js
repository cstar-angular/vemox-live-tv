var Keywords = (function () {
    function Keywords() {
    }
    return Keywords;
}());
export { Keywords };
//# sourceMappingURL=keywords.js.map