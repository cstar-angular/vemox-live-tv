export class Scheduling {
  age_rating: Array<any>;
  channel_id: number;
  description: string;
  duration: number;
  empty_slot: number;
  end_time: number;
  end_time_string: string;
  id: number;
  image: any;
  isPlaying: boolean;
  left: number;
  name: string;
  rating: number;
  short_description: string;
  slug: string;
  start_time: number;
  start_time_string: string;
  type: string;
  width: number;
}
