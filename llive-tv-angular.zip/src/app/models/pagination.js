var Pagination = (function () {
    function Pagination() {
    }
    return Pagination;
}());
export { Pagination };
//# sourceMappingURL=pagination.js.map