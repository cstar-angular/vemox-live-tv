export class Pagination {
  url: any;
  page: number;
  limit: number;
  total_size: number;
}
