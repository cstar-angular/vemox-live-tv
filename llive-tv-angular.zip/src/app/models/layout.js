var Layout = (function () {
    function Layout() {
    }
    return Layout;
}());
export { Layout };
//# sourceMappingURL=layout.js.map