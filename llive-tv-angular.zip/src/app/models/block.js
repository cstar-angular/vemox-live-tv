var Block = (function () {
    function Block() {
    }
    return Block;
}());
export { Block };
//# sourceMappingURL=block.js.map