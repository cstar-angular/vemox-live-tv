export class Video {
  streams: object;
  trailer: object;
}
