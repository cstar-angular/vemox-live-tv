export const environment = {
  production: true,
  stripePubKey: '', // TODO: change this to the customer's real strip public key
  fbParams: {
    appId: '',      // TODO: change this to the customer's real FB account app id
    xfbml: true,
    version: 'v2.8'
  }
};
